<!-- jQuery  -->
<script src="../include/assets/js/jquery.min.js"></script>
<script src="../include/assets/js/tether.min.js"></script><!-- Tether for Bootstrap -->
<script src="../include/assets/js/bootstrap.min.js"></script>
<script src="../include/assets/js/metisMenu.min.js"></script>
<script src="../include/assets/js/waves.js"></script>
<script src="../include/assets/js/jquery.slimscroll.js"></script>

<!-- plugin js -->
<script src="../include/plugins/moment/moment.js"></script>
<script src="../include/plugins/timepicker/bootstrap-timepicker.js"></script>
<script src="../include/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<script src="../include/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script src="../include/plugins/clockpicker/js/bootstrap-clockpicker.min.js"></script>
<script src="../include/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

<!-- Init js -->
<script src="../include/assets/pages/jquery.form-pickers.init.js"></script>

<!-- App js -->
<script src="../include/assets/js/jquery.core.js"></script>
<script src="../include/assets/js/jquery.app.js"></script>
